package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.beans.Country;
import com.example.demo.services.CountryService;

@RestController
public class CountryController {
	
//	@Autowired
//	CountryService countryService;
//	
//	@GetMapping("/getcountries")
//	public List getCountries()
//	{
//		return countryService.getAllCountries();
//	}
//	
//	@PostMapping("/addcountry")
//	public Country addCountry(@RequestBody Country country)
//	{
//		return countryService.addCountry(country);
//	}
	
	@Autowired
	CountryService countryService;
	
	@GetMapping("/getcountries")
	public List<Country> getCountries()
	{
		return countryService.getAllCountries();
	}
	
	@PostMapping("/addcountry")
	public Country addCountry(@RequestBody Country country)
	{
		return countryService.addCountry(country);
	}

}
