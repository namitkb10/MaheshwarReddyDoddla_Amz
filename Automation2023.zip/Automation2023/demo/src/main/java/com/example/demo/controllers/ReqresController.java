package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.beans.Country;
import com.example.demo.beans.Reqres;
import com.example.demo.services.ReqresService;

@RestController
public class ReqresController {
	
	@Autowired
	ReqresService reqresService;
	
	@PostMapping
	public Reqres addUser(@RequestBody Reqres reqres)
	{
		return reqresService.addUser(reqres);
	}

}
