package com.example.demo.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Component;

import com.example.demo.beans.Country;
import com.example.demo.beans.Reqres;

@Component
public class ReqresService {
	
	//static HashMap<Integer, Reqres> reqresMap;
	static List<Reqres> list=new ArrayList<Reqres>();
	
	public Reqres addUser(Reqres reqres)
	{
		list.add(reqres);
		return reqres;
	
	}
	

}
