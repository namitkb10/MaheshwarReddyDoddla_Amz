package com.example.demo;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
public class UsersController {
	
//	@GetMapping
//	public String getUsers()
//	{
//		return "Http get request";
//	}
//	
	@GetMapping
	public String getUsers(@RequestParam(value="page") int pageNo,@RequestParam(value="limit") int limitNo)
	{
		return "Http get request" + pageNo+" "+limitNo;
	}
	
	@GetMapping(path="/{userID}")
	public String getUser(@PathVariable String userID)
	{
		return "Http get request for single user"+ userID;
	}
	
	@PostMapping
	public String createUser()
	{
		return "Http post request";
	}
	@PutMapping
	public String updateUser()
	{
		return "Http put request";
	}
	@DeleteMapping
	public String deletUser()
	{
		return "Http delete request";
	}

}
