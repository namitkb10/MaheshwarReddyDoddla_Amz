package com.example.demo.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.demo.beans.Country;
import com.example.demo.repositories.CountryRepository;

@Component
@Service
public class CountryService {

//	static HashMap<Integer, Country> CountryIDMap;
//
//	public CountryService() {
//		CountryIDMap = new HashMap<Integer, Country>();
//		Country indiaCountry = new Country(1, "India", "Delhi");
//		Country usaCountry = new Country(2, "USA", "Washington");
//		Country ukCountry = new Country(3, "UK", "London");
//		CountryIDMap.put(1, indiaCountry);
//		CountryIDMap.put(2, usaCountry);
//		CountryIDMap.put(3, ukCountry);
//	}
//	
//	public List getAllCountries()
//	{
//		List countries=new ArrayList(CountryIDMap.values());
//		return countries;
//	}
//	
//	public Country getCountryById(int id)
//	{
//		return CountryIDMap.get(id);
//	}
//	
//	public Country getCountryByName(String countryName)
//	{
//		Country country=null;
//		for(int i:CountryIDMap.keySet())
//		{
//			if(CountryIDMap.get(i).getCountryName().equals(countryName))
//			{
//				country=CountryIDMap.get(i);
//			}
//		}
//		
//		return country;
//		
//	}
//	
//	public Country addCountry(Country country)
//	{
//		country.setId(getMaxId());
//		CountryIDMap.put(country.getId(), country);
//		return country;
//		
//	}
//	
//	public static int getMaxId()
//	{
//		int max=0;
//		for(int i:CountryIDMap.keySet())
//		{
//			if(max<=i)
//				max=i;
//		}
//		
//		return max+1;
//	}
	
	@Autowired
	CountryRepository countryRepository;
	
	public List<Country> getAllCountries()
	{
		return countryRepository.findAll();
	}
	
	public Country addCountry(Country country)
	{
		country.setId(getMaxId()+1);
		countryRepository.save(country);
		return country;
		
	}
	
	public int getMaxId()
	{
		return countryRepository.findAll().size();
	}
	
	
	

}
