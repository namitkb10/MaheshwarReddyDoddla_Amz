package com.example.demo;

import static org.hamcrest.MatcherAssert.assertThat;

import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.spring.CucumberContextConfiguration;
import junit.framework.Assert;

@SpringBootTest
@CucumberContextConfiguration
public class DemoApplicationTests {

	ResponseEntity lastResponse;

	@When("single user endpoint {string}")
	public void whenClientCalls(String url) {
		try {
			lastResponse = new RestTemplate().exchange("https://reqres.in" + url, HttpMethod.GET, null, String.class);
		} catch (HttpClientErrorException httpClientErrorException) {
			httpClientErrorException.printStackTrace();
		}
	}

	@Then("single user response status code is {int}")
	public void thenStatusCodee(int expected) {
		Assertions.assertNotNull(lastResponse);
		Assertions.assertNotNull(lastResponse.getStatusCode());
		assertThat("status code is" + expected, lastResponse.getStatusCodeValue() == expected);
	}

	@Then("single user firstname {string}")
	public void thenStringIs(String expected) throws JSONException {

		JSONObject jo = new JSONObject(lastResponse.getBody().toString());
		String firstName = jo.getJSONObject("data").getString("first_name");
		Assertions.assertEquals(expected, firstName);

	}

	@When("single user not found endpoint {string}")
	public void whenSingleUserNotFoundEndpoint(String url) {
		try {
			lastResponse = new RestTemplate().exchange("https://reqres.in" + url, HttpMethod.GET, null, String.class);
		} catch (HttpClientErrorException httpClientErrorException) {
			httpClientErrorException.printStackTrace();
		}
	}

	@Then("single user not found response status code is {int}")
	public void thenSingleUserNotFoundResponseStatusCodeIs(int expected) {
		Assertions.assertNull(lastResponse);

	}

	@When("list of users endpoint {string}")
	public void list_of_users_endpoint(String url, io.cucumber.datatable.DataTable dataTable) throws JSONException {
		try {
			lastResponse = new RestTemplate().exchange("https://reqres.in" + url, HttpMethod.GET, null, String.class);
		} catch (HttpClientErrorException httpClientErrorException) {
			httpClientErrorException.printStackTrace();
		}
		List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
		JSONObject jo = new JSONObject(lastResponse.getBody().toString());
		int count = jo.getInt("per_page");
		for (int i = 0; i < data.size(); i++) {
			int id = Integer.parseInt(data.get(i).get("Id"));
			String firstName = data.get(i).get("FirstName");
			String lastName = data.get(i).get("LastName");
			String email = data.get(i).get("Email");

			for (int j = 0; j <= count; j++) {
				int ID = Integer.parseInt(jo.getJSONArray("data").getJSONObject(i).get("id").toString());
				if (id == ID) {
					String fn = jo.getJSONArray("data").getJSONObject(i).getString("first_name");
					String ln = jo.getJSONArray("data").getJSONObject(i).getString("last_name");
					String em = jo.getJSONArray("data").getJSONObject(i).getString("email");
					Assertions.assertEquals(firstName, fn);
					Assertions.assertEquals(lastName, ln);
					Assertions.assertEquals(email, em);
				}
			}

		}

	}

	@Then("list of users response status code is {int}")
	public void list_of_users_response_status_code_is(Integer expected) {
		Assertions.assertNotNull(lastResponse);
		Assertions.assertNotNull(lastResponse.getStatusCode());
		assertThat("status code is" + expected, lastResponse.getStatusCodeValue() == expected);
		System.out.println(lastResponse.getStatusCodeValue());

	}

}
