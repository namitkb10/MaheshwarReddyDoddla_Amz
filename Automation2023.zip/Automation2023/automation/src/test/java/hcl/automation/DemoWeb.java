package hcl.automation;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

public class DemoWeb {
	
	@Test
	public void testDemoWeb()
	{
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get("https://demowebshop.tricentis.com/");
		
		WebElement computersElement=driver.findElement(By.xpath("(//a[@href='/computers'])[1]"));
		Actions actions=new Actions(driver);
		actions.moveToElement(computersElement).build().perform();
		WebElement desktopsElement=driver.findElement(By.xpath("(//a[@href='/desktops'])[1]"));
		
		desktopsElement.click();
		
		String currentUrl=driver.getCurrentUrl();
		Assert.assertEquals(currentUrl, "https://demowebshop.tricentis.com/desktops");
		
		WebElement ddPosition=driver.findElement(By.id("products-orderby"));
		
		Select select =new Select(ddPosition);
		List<WebElement> list=select.getOptions();
		
		System.out.println(list.size());
		
		for(WebElement ele:list)
		{
			System.out.println(ele.getText());
		}
		
		String computerType=driver.findElement(By.linkText("Build your own cheap computer")).getText();
		
		driver.findElement(By.linkText("Build your own cheap computer")).click();
		
		if(computerType.equals("Build your own cheap computer"))
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
		driver.findElement(By.id("product_attribute_72_6_19_91")).click();
		driver.findElement(By.id("product_attribute_72_8_30_93")).click();
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,200)");
		driver.findElement(By.id("addtocart_72_EnteredQuantity")).clear();
		driver.findElement(By.id("addtocart_72_EnteredQuantity")).sendKeys("2");
		driver.findElement(By.id("add-to-cart-button-72")).click();
		String successMessage=driver.findElement(By.xpath("//p[@class='content']")).getText();
		Assert.assertEquals(successMessage, "The product has been added to your shopping cart");
		driver.quit();
		
		
	}

}
