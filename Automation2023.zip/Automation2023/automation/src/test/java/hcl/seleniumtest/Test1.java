package hcl.seleniumtest;

import org.testng.annotations.Test;

public class Test1 {
	
	
	@Test
	public void method1()
	{
		
		WebDriver driver=new ChromeDriver();
		
	}

}
