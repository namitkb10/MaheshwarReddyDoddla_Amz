package dbs.automation;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class Reports {
	
	public static void main(String[] args) throws IOException {
		
		ExtentReports extentReports=new ExtentReports();
		//ExtentSparkReporter extentSparkReporter=new ExtentSparkReporter("C:\\Users\\Mahesh\\Automation2023\\automation\\target\\ExtentReports\\Report.html");
		//ExtentSparkReporter extentSparkReporter=new ExtentSparkReporter("Report.html");
		File file=new File("Report.html");
		ExtentSparkReporter extentSparkReporter=new ExtentSparkReporter(file);
		extentReports.attachReporter(extentSparkReporter);
		ExtentTest extentTest=extentReports.createTest("Test1");
		extentTest.pass("This is passed");
		
		ExtentTest extentTest2=extentReports.createTest("Test2");
		extentTest2.log(Status.FAIL, "This is failed");
		
		extentReports.createTest("Test3").skip("This is skipped");
		
		
		extentReports.flush();
		Desktop.getDesktop().browse(file.toURI());
	}

}
