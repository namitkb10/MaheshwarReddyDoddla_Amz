package com.hcl.base;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class BaseEngine {
	
	private static WebDriver driver;
	private static ExtentSparkReporter spark;
	private static ExtentReports extentReports;
	private static ExtentTest extentTest;
	
	
	@Parameters({"browser"})
	@BeforeSuite
	public void openBrowser(@Optional("chrome")String browser)
	{
		if(browser.equals("chrome"))
		{
			driver=new ChromeDriver();
		}
		else if(browser.equals("edge"))
		{
			driver=new EdgeDriver();
		}
		else if(browser.equals("firefox"))
		{
			driver=new FirefoxDriver();
		}
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
	}
	
	@AfterSuite
	public void closeBrowser()
	{
		driver.quit();
	}
	
	@BeforeMethod
	public void runTimeTCExeName(Method method) {
		String tcName = method.getName();
		System.out.println("NOW EXECUTING : " + tcName);
		extentTest = extentReports.createTest(tcName);
		
	}
	@AfterMethod
	public void afterTCExec(ITestResult result) throws IOException {
		String tcName = result.getName();
		extentReports.flush();
	}
	@BeforeTest
	public void initialiseReport()
	{
		String reportLoc = System.getProperty("user.dir")+"\\Reports\\report.html";
		spark = new ExtentSparkReporter(reportLoc);
		extentReports=new ExtentReports();
		extentReports.attachReporter(spark);
		
	}
	@AfterTest
	public void endReport() throws IOException
	{
//		File file=new File("C:\\Users\\Mahesh\\Automation2023\\auto\\Reports\\report.html");
//		Desktop.getDesktop().browse(file.toURI());
	}
	public static ExtentTest getExtentTest()
	{
		return extentTest; 
	}
	
	public static WebDriver getDriver() {
		return driver;
	}
	
}
