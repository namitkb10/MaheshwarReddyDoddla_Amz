package com.hcl.utility;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Random;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.aventstack.extentreports.ExtentTest;
import com.hcl.base.BaseEngine;

public class ScreenshotUtility {
	
	public static String screenShot() throws IOException
	{
		Random random=new Random();
		int i=random.nextInt(0, 100);
		String projPath = System.getProperty("user.dir")+"\\Screenshots"+"\\"+i+".jpeg";
		TakesScreenshot ts = (TakesScreenshot)BaseEngine.getDriver();
		File file = ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file, new File(projPath));
		return projPath;
		
	}

}
