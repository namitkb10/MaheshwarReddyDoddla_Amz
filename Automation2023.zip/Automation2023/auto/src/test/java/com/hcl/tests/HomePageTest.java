package com.hcl.tests;

import java.io.IOException;

import org.testng.annotations.Test;

import com.hcl.base.BaseEngine;
import com.hcl.pages.HomePage;

public class HomePageTest extends BaseEngine{
	
	HomePage homePage=new HomePage();
	
	@Test
	public void HomePageTestMethod() throws InterruptedException, IOException
	{
		homePage.launchApp();
		homePage.getMenuNamesAndPrintOnConsole();
		homePage.getCountOfMenus();
		homePage.captureScreenshotAndCompareWithExecptedScreenshot();
	}

}
