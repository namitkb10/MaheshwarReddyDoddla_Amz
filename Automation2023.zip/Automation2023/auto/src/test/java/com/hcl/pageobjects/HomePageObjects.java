package com.hcl.pageobjects;

import org.openqa.selenium.By;

public class HomePageObjects {
	
	public By allMenus=By.xpath("//li//a[@href and @title]");
	
	public By btnAcceptAllCookies=By.id("onetrust-accept-btn-handler");

}
