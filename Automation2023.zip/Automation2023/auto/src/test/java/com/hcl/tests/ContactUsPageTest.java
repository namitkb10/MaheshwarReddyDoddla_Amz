package com.hcl.tests;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.Test;

import com.hcl.base.BaseEngine;
import com.hcl.filereaders.ExcelReader;
import com.hcl.pages.ContactUsPage;
import com.hcl.pages.HomePage;

public class ContactUsPageTest extends BaseEngine {
	
	HomePage homePage=new HomePage();
	ContactUsPage contactUsPage=new ContactUsPage();
	
	
	
	@Test
	public void contactUsPageTestMethod() throws IOException, EncryptedDocumentException, InvalidFormatException, InterruptedException
	{
		
		homePage.launchApp();
		contactUsPage.clickOnContactUs();
		contactUsPage.validateFormFields();
		contactUsPage.enterFormDetails();
		
	
	}
			

}
