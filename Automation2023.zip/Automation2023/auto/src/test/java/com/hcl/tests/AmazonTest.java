package com.hcl.tests;

import java.io.IOException;

import org.testng.annotations.Test;

import com.hcl.base.BaseEngine;
import com.hcl.pages.AmazonPage;

public class AmazonTest extends BaseEngine {
	
	AmazonPage amazonPage=new AmazonPage();
	
	@Test
	public void amazonTestMethod() throws IOException, InterruptedException
	{
		amazonPage.launchApp();
		amazonPage.mousehoverOnMobilesAndClick();
		amazonPage.printSubLinksAndCount();
		//amazonPage.compareScreenshot();
		amazonPage.mousehoverOnLatopsAccessosiesAndClickOnBrand();
		amazonPage.setMinAndMaxPriceAndGo();
		amazonPage.searchGamingLaptop();
		amazonPage.clickOnFirstGamingLaptopOnScreen();
		amazonPage.verifyPriceShouldBeGreaterThanEqualZero();
		amazonPage.selectDeliveryLocationAndEnterPincode();
		amazonPage.printCustomerRatingOnConsole();
		amazonPage.readCustomerReviewsAndWriteInExcel();
		amazonPage.scrollUpAndClickOnAddCart();
		
	}

}
