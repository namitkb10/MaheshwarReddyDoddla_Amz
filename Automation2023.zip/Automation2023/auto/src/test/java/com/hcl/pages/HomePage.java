package com.hcl.pages;


import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.function.Function;

import javax.imageio.ImageIO;
import javax.lang.model.element.Element;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.hcl.base.BaseEngine;
import com.hcl.pageobjects.HomePageObjects;
import com.hcl.tests.HomePageTest;
import com.hcl.utility.ScreenshotUtility;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class HomePage extends BaseEngine{
	
	HomePageObjects homePageObjects=new HomePageObjects();
	int count=0;
	public void launchApp() throws IOException
	{
		getDriver().get("https://www.hcltech.com/");
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
	}
	
	public  void getMenuNamesAndPrintOnConsole() throws IOException
	{
		List<WebElement> listOfMenus=getDriver().findElements(homePageObjects.allMenus);
		for(WebElement ele:listOfMenus)
		{
			if(!ele.getText().equals(""))
			{
			System.out.println(ele.getText());
			count++;
			}
		}
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
	}
	
	public void getCountOfMenus()
	{
		System.out.println("Number of Menus and Sub Menus: "+count);
	}
	
	public void captureScreenshotAndCompareWithExecptedScreenshot() throws InterruptedException, IOException
	{
		getDriver().findElement(homePageObjects.btnAcceptAllCookies).click();
		Thread.sleep(3000);
//		TakesScreenshot ts=(TakesScreenshot)getDriver();
//		File source=ts.getScreenshotAs(OutputType.FILE);
//		try {
//			FileUtils.copyFile(source, new File("C:\\Users\\Mahesh\\Automation2023\\auto\\src\\test\\java\\HomaPageScreenshots\\ActualScreenshot.png"));
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
//		WebElement image=getDriver().findElement(By.xpath("//img[@alt='HCLTech']"));
//		Screenshot ImageScreenshot = new AShot().takeScreenshot(getDriver(), image);
//		BufferedImage actualImage=ImageScreenshot.getImage();
//		ImageIO.write(actualImage, "png", new File("C:\\Users\\Mahesh\\Automation2023\\auto\\src\\test\\java\\HomaPageScreenshots\\new1.png"));
		

		Screenshot screenshot = new AShot().takeScreenshot(getDriver());
		ImageIO.write(screenshot.getImage(), "png", new File("C:\\Users\\Mahesh\\Automation2023\\auto\\src\\test\\java\\HomaPageScreenshots\\Actual.png"));
		
		 ImageDiffer imgDiff = new ImageDiffer();
		 ImageDiff diff = imgDiff.makeDiff(ImageIO.read(new File("C:\\Users\\Mahesh\\Automation2023\\auto\\src\\test\\java\\HomaPageScreenshots\\Actual.png")), ImageIO.read(new File("C:\\Users\\Mahesh\\Automation2023\\auto\\src\\test\\java\\HomaPageScreenshots\\Expected.png")));
	        Assert.assertFalse(diff.hasDiff(),"Images are Same");
	}

}
