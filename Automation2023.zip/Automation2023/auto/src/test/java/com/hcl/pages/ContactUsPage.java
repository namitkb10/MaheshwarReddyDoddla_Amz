package com.hcl.pages;

import java.io.IOException;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.hcl.base.BaseEngine;
import com.hcl.filereaders.ExcelReader;
import com.hcl.pageobjects.ContactUsPageObjects;
import com.hcl.utility.ScreenshotUtility;

public class ContactUsPage extends BaseEngine {
	
	
	ContactUsPageObjects contactUsPageObjects=new ContactUsPageObjects();
	
	
	public void clickOnContactUs() throws IOException
	{
		getDriver().findElement(contactUsPageObjects.lblContactUs).click();
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		
	}

	public void validateFormFields() throws IOException, InterruptedException
	{
		getDriver().findElement(contactUsPageObjects.btnAcceptAllCookies).click();
		Thread.sleep(3000);
		getDriver().findElement(contactUsPageObjects.btnSubmit).click();
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		Assert.assertEquals(getDriver().findElement(contactUsPageObjects.errorMessageName).getText(),
				"Full Name field is required.");
		Assert.assertEquals(getDriver().findElement(contactUsPageObjects.errorMessageEmail).getText(),
				"Business Email Address field is required.");
		Assert.assertEquals(getDriver().findElement(contactUsPageObjects.errorMessageCountry).getText(), "Country field is required.");
		Assert.assertEquals(getDriver().findElement(contactUsPageObjects.errorMessageRelationship).getText(),
				"Relationship to HCLTech field is required.");
		Assert.assertEquals(getDriver().findElement(contactUsPageObjects.errorMessageComments).getText(),
				"How can we help you? field is required.");
		Assert.assertEquals(getDriver().findElement(contactUsPageObjects.errorMessagePolicy).getText(),
				"Privacy policy field is required.");
		getDriver().findElement(contactUsPageObjects.tbEmail).sendKeys("mahesh");
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		Assert.assertEquals(getDriver().findElement(contactUsPageObjects.errorMessageEmail).getText(),
				"The value in Business Email Address is not a valid email address.");
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		getDriver().findElement(contactUsPageObjects.tbPhone).sendKeys("901001");
		getDriver().findElement(contactUsPageObjects.tbOrganization).click();
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		Assert.assertEquals(getDriver().findElement(contactUsPageObjects.errorMessagePhone).getText(),
				"Please enter at least 8 characters.");
		
	}
	
	public void enterFormDetails() throws EncryptedDocumentException, InvalidFormatException, IOException
	{
		ExcelReader excelReader=
				new ExcelReader("C:\\Users\\Mahesh\\Automation2023\\auto\\TestData\\FormData.xlsx");
		String sheetName="HCLTECHDATA";
		System.out.println(excelReader.getRowCount(sheetName));
		for(int i=2;i<=excelReader.getRowCount(sheetName);i++)
		{
			String name=excelReader.getCellData(sheetName, "Name", i);
			String email=excelReader.getCellData(sheetName, "Email", i);
			String organization=excelReader.getCellData(sheetName, "Organization", i);
			String phone=excelReader.getCellData(sheetName, "Phone", i);
			System.out.println(phone);
			String country=excelReader.getCellData(sheetName, "Country", i);
			String relationship=excelReader.getCellData(sheetName, "Relationship", i);
			String comments=excelReader.getCellData(sheetName, "Comments", i);
			String file=excelReader.getCellData(sheetName, "File", i);
			
			System.out.println(file);
			
						
			getDriver().findElement(contactUsPageObjects.tbName).sendKeys(name);
			getDriver().findElement(contactUsPageObjects.tbEmail).clear();
			getDriver().findElement(contactUsPageObjects.tbEmail).sendKeys(email);
			
			getDriver().findElement(contactUsPageObjects.tbOrganization).clear();
			getDriver().findElement(contactUsPageObjects.tbOrganization).sendKeys(organization);
			
			getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
			
			getDriver().findElement(contactUsPageObjects.tbPhone).clear();
			getDriver().findElement(contactUsPageObjects.tbPhone).sendKeys(phone);
			
			WebElement countryDD = getDriver().findElement(contactUsPageObjects.ddEditCountry);
			Select selectCountry = new Select(countryDD);
			selectCountry.selectByValue(country);
			
			WebElement relationshipDD = getDriver().findElement(contactUsPageObjects.ddEditRelationship);
			Select selectRelationship = new Select(relationshipDD);
			selectRelationship.selectByValue(relationship);
			getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
			
			getDriver().findElement(contactUsPageObjects.textFieldComments).sendKeys(comments);
			
			getDriver().findElement(contactUsPageObjects.btnUploadFile).sendKeys(file);
			
			getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
			
		}
		
		
	}
}
