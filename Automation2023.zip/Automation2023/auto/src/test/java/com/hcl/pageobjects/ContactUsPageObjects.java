package com.hcl.pageobjects;

import org.openqa.selenium.By;

public class ContactUsPageObjects {
	
	public By lblContactUs=By.linkText("Contact Us");
	public By tbName=By.id("edit-full-name");
	public By tbEmail=By.id("edit-email-address");
	public By tbOrganization=By.id("edit-organization");
	public By tbPhone=By.id("edit-phone");
	public By ddEditCountry=By.id("edit-country");
	public By ddEditRelationship=By.id("edit-query-type");
	public By textFieldComments=By.id("edit-message-comments");
	public By btnUploadFile=By.id("edit-upload-multifile-upload");
	public By btnSubmit=By.id("edit-actions-submit");
	public By errorMessageName=By.id("edit-full-name-error");
	public By errorMessageEmail=By.id("edit-email-address-error");
	public By errorMessageCountry=By.id("edit-country-error");
	public By errorMessageRelationship=By.id("edit-query-type-error");
	public By errorMessageComments=By.id("edit-message-comments-error");
	public By errorMessagePolicy=By.id("privacy_policy-error");
	public By btnAcceptAllCookies=By.id("onetrust-accept-btn-handler");
	public By errorMessagePhone=By.id("edit-phone-error");
	

}
