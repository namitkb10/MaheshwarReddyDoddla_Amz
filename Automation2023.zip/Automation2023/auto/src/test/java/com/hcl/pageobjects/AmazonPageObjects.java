package com.hcl.pageobjects;

import org.openqa.selenium.By;

public class AmazonPageObjects {
	
	public By menuLinks=By.xpath("//div[@id='nav-xshop']//a");
	public By linkMobiles=By.xpath("//a[text()='Mobiles']");
	public By sublinks=By.xpath("//div[@id='nav-progressive-subnav']//a");
	public By linkLaptopsAccessories=By.xpath("//span[contains(text(),'Laptops & Accessories')]");
	public By linkBrand=By.linkText("Dell");
	public By tbLowPrice=By.id("low-price");
	public By tbHighPrice=By.id("high-price");
	public By btnGo=By.xpath("//input[@id='high-price']//following-sibling::*");
	public By tbSearchLaptop=By.xpath("//input[@id='twotabsearchtextbox']");
	public By btnSearch=By.id("nav-search-submit-button");
	public By firstLaptop=By.xpath("(//a[@class='a-link-normal s-no-outline'])[1]");
	public By laptopPrice=By.xpath("//span[@class='a-price aok-align-center reinventPricePriceToPayMargin priceToPay']//span[@class='a-price-whole']");
	public By updatelocation=By.xpath("//div[@id='glow-ingress-block']//span[2]");
	public By tbPincode=By.id("GLUXZipUpdateInput");
	public By btnApply=By.xpath("//span[@id='GLUXZipUpdate-announce']//preceding-sibling::*");
	public By lblCustomerReviews=By.xpath("//h2[text()='Customer reviews']");
	public By lblRating=By.xpath("//span[@data-hook='rating-out-of-text']");
	public By reviewerName=By.xpath("//h3[contains(text(),' Top reviews from India')]//following::*//span[@class='a-profile-name']");
	public By lblTopReviewsFromIndia=By.xpath("//h3[contains(text(),' Top reviews from India')]");
	public By customerReview=By.xpath("(//h3[contains(text(),' Top reviews from India')]//following::*//span[@class='a-profile-name'])[1]//following::*//span[@data-hook='review-body']");
	public By btnAddCart=By.id("add-to-cart-button");
	public By btnAddedCart=By.xpath("(//h4[text()='Added to Cart'])[2]");

}
