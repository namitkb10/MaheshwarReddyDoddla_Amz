package com.hcl.pages;

import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.imageio.ImageIO;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.google.common.collect.Table.Cell;
import com.hcl.base.BaseEngine;
import com.hcl.pageobjects.AmazonPageObjects;
import com.hcl.seleniumfunctions.SeleniumMethods;
import com.hcl.utility.ScreenshotUtility;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;

public class AmazonPage extends BaseEngine {

	SeleniumMethods seleniumMethods = new SeleniumMethods();
	AmazonPageObjects amazonPageObjects = new AmazonPageObjects();

	public void launchApp() throws IOException {
		getDriver().get("https://www.amazon.in/");
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
	}

	public void mousehoverOnMobilesAndClick() throws IOException {
		seleniumMethods.mousehover(getDriver().findElement(amazonPageObjects.linkMobiles));
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		seleniumMethods.click(getDriver().findElement(amazonPageObjects.linkMobiles));
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());

	}

	public void printSubLinksAndCount() throws IOException {
		List<String> list = seleniumMethods.getTextOfElements(getDriver().findElements(amazonPageObjects.sublinks));
		int count = 0;
		System.out.println("------Menus---------");
		for (String str : list) {
			System.out.println(str);
			count++;
		}
		System.out.println("Menus Count:" + count);
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
	}

	public void compareScreenshot() throws IOException {
		Screenshot screenshot = new AShot().takeScreenshot(getDriver());
		ImageIO.write(screenshot.getImage(), "png",
				new File("C:\\Users\\Mahesh\\Automation2023\\auto\\src\\main\\java\\AmazonScreenshots\\Actual.png"));

		ImageDiffer imgDiff = new ImageDiffer();
		ImageDiff diff = imgDiff.makeDiff(
				ImageIO.read(new File(
						"C:\\Users\\Mahesh\\Automation2023\\auto\\src\\main\\java\\AmazonScreenshots\\Actual.png")),
				ImageIO.read(new File(
						"C:\\Users\\Mahesh\\Automation2023\\auto\\src\\main\\java\\AmazonScreenshots\\Expected.png")));
		Assert.assertFalse(diff.hasDiff(), "Images are Same");
	}

	public void mousehoverOnLatopsAccessosiesAndClickOnBrand() throws IOException {
		seleniumMethods.mousehover(getDriver().findElement(amazonPageObjects.linkLaptopsAccessories));
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		seleniumMethods.click(getDriver().findElement(amazonPageObjects.linkBrand));

	}

	public void setMinAndMaxPriceAndGo() throws IOException {
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		seleniumMethods.enterText(getDriver().findElement(amazonPageObjects.tbLowPrice), "40000");
		seleniumMethods.enterText(getDriver().findElement(amazonPageObjects.tbHighPrice), "100000");
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		seleniumMethods.click(getDriver().findElement(amazonPageObjects.btnGo));
	}

	public void searchGamingLaptop() throws IOException {
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		seleniumMethods.enterText(getDriver().findElement(amazonPageObjects.tbSearchLaptop), "Gaming Laptop");
		seleniumMethods.click(getDriver().findElement(amazonPageObjects.btnSearch));
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
	}

	public void clickOnFirstGamingLaptopOnScreen() throws IOException {
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		seleniumMethods.click(getDriver().findElement(amazonPageObjects.firstLaptop));
	}

	public void verifyPriceShouldBeGreaterThanEqualZero() throws NumberFormatException, IOException {
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		Set<String> allWindows = getDriver().getWindowHandles();
		seleniumMethods.swithToWindow(allWindows);
		int price = Integer.parseInt(seleniumMethods
				.getTextOfElement(getDriver().findElement(amazonPageObjects.laptopPrice)).replace(",", ""));
		if (price >= 0) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false);
		}
		System.out.println(price);

	}

	public void selectDeliveryLocationAndEnterPincode() throws IOException {
		seleniumMethods.click(getDriver().findElement(amazonPageObjects.updatelocation));
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		seleniumMethods.click(getDriver().findElement(amazonPageObjects.tbPincode));
		Actions actions = new Actions(getDriver());
		actions.sendKeys(Keys.NUMPAD5).sendKeys(Keys.NUMPAD0).sendKeys(Keys.NUMPAD0).sendKeys(Keys.NUMPAD0)
				.sendKeys(Keys.NUMPAD7).sendKeys(Keys.NUMPAD2).build().perform();
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		seleniumMethods.click(getDriver().findElement(amazonPageObjects.btnApply));
	}

	public void printCustomerRatingOnConsole() throws InterruptedException, IOException {
		Thread.sleep(3000);
		
		seleniumMethods.scrollDown(getDriver().findElement(amazonPageObjects.lblCustomerReviews));
		String rating = seleniumMethods.getTextOfElement(getDriver().findElement(amazonPageObjects.lblRating));
		System.out.println(rating);
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());

	}

	public void readCustomerReviewsAndWriteInExcel() throws IOException, InterruptedException {

		seleniumMethods.scrollDown(getDriver().findElement(amazonPageObjects.lblTopReviewsFromIndia));
		List<String> reviewerNames = seleniumMethods
				.getTextOfElements(getDriver().findElements(amazonPageObjects.reviewerName));
		List<String> reviews = seleniumMethods
				.getTextOfElements(getDriver().findElements(amazonPageObjects.customerReview));
		List<String> names = new ArrayList<String>();

		for (String str : reviewerNames) {
			if (!str.isEmpty())
			{
				names.add(str);
			}
		}
		for (int i = 0; i < names.size(); i++) {
			System.out.println("--------" + names.get(i) + "------------");
			System.out.println("*" + reviews.get(i).trim() + "*");
		}
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet();
		XSSFRow row;
		Map<String, String> reviewsdata = new TreeMap<String, String>();

		for (int i = 0; i < names.size(); i++) {
		reviewsdata.put(names.get(i), reviews.get(i));	
		}
		Set<String> keyid = reviewsdata.keySet();
		int rowid = 0;
		String str="";
//		XSSFCellStyle cs=wb.createCellStyle();
//		cs.setWrapText(true);
		for (String key : keyid) {

			row = sheet.createRow(rowid);
			if(!reviewsdata.get(key).isEmpty())
			{
			 str = reviewsdata.get(key);
			}
			else
			{
			 str="No Review";
			}
			int cellid = 0;
			XSSFCell cell1 = row.createCell(cellid);
			cell1.setCellValue(key);
			//cell1.setCellStyle(cs);
			XSSFCell cell2 = row.createCell(cellid + 1);
			cell2.setCellValue(str);
			//cell2.setCellStyle(cs);
			rowid++;

		}
		FileOutputStream file = new FileOutputStream(
				"C:\\Users\\Mahesh\\Automation2023\\auto\\AmazonExcelFiles\\amazonreviews.xlsx");

		wb.write(file);
		wb.close();
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());

	}
	
	public void scrollUpAndClickOnAddCart() throws InterruptedException, IOException
	{
		seleniumMethods.scrollUp(getDriver().findElement(amazonPageObjects.btnAddCart));
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		seleniumMethods.click(getDriver().findElement(amazonPageObjects.btnAddCart));
		Thread.sleep(10000);
		Assert.assertTrue(seleniumMethods.isElementPresent(getDriver().findElement(amazonPageObjects.btnAddedCart)));
		getExtentTest().addScreenCaptureFromPath(ScreenshotUtility.screenShot());
		
	}

}
