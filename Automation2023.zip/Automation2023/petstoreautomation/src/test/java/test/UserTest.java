package test;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import endpoints.UserEndPoints;
import io.restassured.response.Response;
import junit.framework.Assert;
import payload.User;

public class UserTest {
	
	Faker faker;
	User userpayload;
	
	@BeforeClass
	public void setupdata()
	{
		faker=new Faker();
		userpayload=new User();
		userpayload.setId(faker.idNumber().hashCode());
		userpayload.setFirstName(faker.name().firstName());
		userpayload.setLastName(faker.name().lastName());
		userpayload.setUsername(faker.name().username());
		userpayload.setEmail(faker.internet().safeEmailAddress());
		userpayload.setPassword(faker.internet().password(5,10));
		userpayload.setPhone(faker.phoneNumber().cellPhone());
		
		
	}
	
	@Test(priority=0)
	public void testpostuser()
	{
		Response response=UserEndPoints.createuser(userpayload);
		response.then().log().all();
		Assert.assertEquals(200, response.getStatusCode());
	}
	
	@Test(priority=1)
	public void testgetuserByName()
	{
		Response response=UserEndPoints.readuser(this.userpayload.getUsername());
		response.then().log().all();
		Assert.assertEquals(200, response.getStatusCode());
	}
	
	

}
