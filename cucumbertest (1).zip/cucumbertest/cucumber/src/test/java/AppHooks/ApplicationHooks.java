package AppHooks;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.qa.util.ConfigReader;

import DriverUtils.DriverFactory;
import io.cucumber.core.gherkin.Step;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.Scenario;

public class ApplicationHooks {

	public static WebDriver driver;
	private DriverFactory df;
	private ConfigReader cr;
	private Properties prop;
	public ExtentSparkReporter spark;
	public static ExtentReports extent;
	public static ExtentTest logger;
	public static Scenario scenario;

	String dateName = new SimpleDateFormat("yyyy-MM-dd-hh:mm:ss").format(new Date());

	@Before(order = 0)
	public void getProperty() {
		cr = new ConfigReader();
		prop = cr.init_Prop();

	}

	@Before(order = 1)
	public void launchBrowser() {
		df = new DriverFactory();
		driver = df.init_Driver(prop.getProperty("browser"));

	}

	@Before(order = 2)
	public void startReport(Scenario scanario) {
		extent = new ExtentReports();
		spark = new ExtentSparkReporter(
				System.getProperty("user.dir") + "/test-output/STMExtentReport.html");
		extent.attachReporter(spark);
		this.scenario = scanario;

	}

	@BeforeStep(order=3)
	public void beforeStep(Scenario scenario)
	{
		String screenshotName=scenario.getName();
		byte[] source=((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
		scenario.attach(source, "image/png", screenshotName);
		
	}

	@After(order = 0)
	public void quitBrowser() {
		driver.quit();

	}

	@AfterStep(order=2)
	public void afterStep(Scenario scenario)
	{
		String screenshotName=scenario.getName();
		byte[] source=((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
		scenario.attach(source, "image/png", screenshotName);
		
	}

	@After(order = 1)
	public void endReport() {
		extent.flush();
	}

	@After(order = 1)
	public void teardown(Scenario scenario) {
		if (scenario.isFailed()) {
			String screenshotName = scenario.getName();
			byte[] source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			scenario.attach(source, "image/png", screenshotName);

		}

	}

}
