package stepdefiniations;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.qa.util.ScreenshotP;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageobjects.HomePage;
import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;
import AppHooks.ApplicationHooks;


public class hcltechhomepagesteps{
	
	public WebDriver driver=DriverUtils.DriverFactory.getDriver();
	HomePage homePage=new HomePage();
	ExtentTest logger=ApplicationHooks.extent.createTest(ApplicationHooks.scenario.getName());
	Scenario scenario=ApplicationHooks.scenario;
	ScreenshotP ss=new ScreenshotP();
	
	
	@Given("user is on hcltech home page {string}")
	public void user_is_on_hcltech_home_page(String url) throws IOException {
		driver.get(url);
		logger.addScreenCaptureFromPath(ss.getScreenShot("Home Page",scenario.getName()));
	
	}

	
	@When("Print menu items on console")
	public void read_menu_items_and_print_in_cosole_and_also_print_count() throws IOException {

		List<WebElement> li = driver
				.findElements(homePage.allMenus);

		int count = 0;
		for (WebElement ele : li) {
			if (ele.isDisplayed()) {
				System.out.println(ele.getText());
				count++;
			}

		}
		logger.addScreenCaptureFromPath(ss.getScreenShot("Menu Items",scenario.getName()));

		System.out.println("Main Menu Count: " + count);
		

	}

	@When("Print menu items and sub-menu itmes on console")
	public void read_all_menu_and_sub_menu_items_and_print_in_console_and_also_print_count()
			throws InterruptedException, IOException {

		List<WebElement> li = driver
				.findElements(homePage.allMenus);
		Actions actions = new Actions(driver);
		int servicesCount = 0;
		int industriesCount = 0;
		int aboutUsCount = 0;
		int resourcesCount = 0;
		int careersCount = 0;

		for (WebElement ele : li) {

			List<WebElement> li2 = new ArrayList<WebElement>();
			if (ele.getText().equals("Services")) {
				actions.moveToElement(ele).build().perform();
				logger.addScreenCaptureFromPath(ss.getScreenShot("Services Tab",scenario.getName()));
				
				System.out.println("------------" + ele.getText() + "--------------");
				li2 = driver.findElements(homePage.servicesSubMenus);
				for (WebElement ele2 : li2) {

					if (ele2.isDisplayed()) {
						System.out.println(ele2.getText());
						servicesCount++;
					}
				}

			} else if (ele.getText().equals("Industries")) {
				System.out.println("------------" + ele.getText() + "--------------");
				actions.moveToElement(ele).build().perform();
				
				Thread.sleep(5000);
				li2 = driver.findElements(homePage.remainSubMenus);
				for (WebElement ele2 : li2) {
					if (ele2.isDisplayed()) {
						System.out.println(ele2.getText());
						industriesCount++;

					}
				}
			} else if (ele.getText().equals("Resources")) {
				System.out.println("------------" + ele.getText() + "--------------");
				actions.moveToElement(ele).build().perform();
				
				li2 = driver.findElements(homePage.remainSubMenus);
				for (WebElement ele2 : li2) {

					if (ele2.isDisplayed()) {
						System.out.println(ele2.getText());
						resourcesCount++;

					}
				}
			} else if (ele.getText().equals("Careers")) {
				System.out.println("------------" + ele.getText() + "--------------");
				actions.moveToElement(ele).build().perform();
				li2 = driver.findElements(homePage.remainSubMenus);
				for (WebElement ele2 : li2) {

					if (ele2.isDisplayed()) {
						System.out.println(ele2.getText());
						careersCount++;

					}
				}
			}

			else if (ele.getText().equals("About Us")) {
				System.out.println("------------" + ele.getText() + "--------------");
				actions.moveToElement(ele).build().perform();
				li2 = driver.findElements(homePage.remainSubMenus);
				for (WebElement ele2 : li2) {

					if (ele2.isDisplayed()) {
						System.out.println(ele2.getText());
						aboutUsCount++;

					}
				}
			}

		}

		System.out.println("Services Sub Menu Count" + servicesCount);
		System.out.println("Services Sub Menu Count" + industriesCount);
		System.out.println("Services Sub Menu Count" + aboutUsCount);
		System.out.println("Services Sub Menu Count" + resourcesCount);
		System.out.println("Services Sub Menu Count" + careersCount);

	}

	@When("capture screenshot of HCL Tech")
	public void capture_screenshot_of_hcl_tech() throws IOException {

//		WebElement ele = driver.findElement(By.xpath("(//div[@class='item item1 flex-row'])[1]"));
//		String img= ele.getCssValue("background");
//		String imgUrl = img.substring(img.indexOf('"') + 1, img.lastIndexOf('"'));
//		File file=new File("D:\\Serenity2023\\cucumber\\logo-forum.png");
//		//System.out.println(imgUrl);
//		//URL url = new URL(imgUrl);
//		BufferedImage saveImage = ImageIO.read(file);
//
//		ImageIO.write(saveImage, "png", new File("logo.png"));
		
//		WebElement ele = driver.findElement(By.xpath("//img[@title='HCLTech']"));
//		String img= ele.getAttribute("src");
//		URL url = new URL(img);
//		BufferedImage saveImage = ImageIO.read(url);
//
//		ImageIO.write(saveImage, "svg", new File("D:\\Serenity2023\\cucumber\\src\\test\\resources\\ActualImages\\logo.svg"));
		
		TakesScreenshot ts=(TakesScreenshot)driver;
		File file=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file, new File("D:\\Serenity2023\\cucumber\\src\\test\\resources\\ActualImages\\HomePage.jpg"));
		

	}

	@Then("verify screenshot with original screenshot")
	public void verify_screenshot_with_original_screenshot() throws IOException {
		
		ImageDiffer imageDiffer=new ImageDiffer();
		ImageDiff diff = imageDiffer.makeDiff(ImageIO.read(new File("D:\\Serenity2023\\cucumber\\src\\test\\resources\\ActualImages\\HomePage.jpg")), ImageIO.read(new File("D:\\Serenity2023\\cucumber\\src\\test\\resources\\ExpectedImages\\HomePage.jpg")));
	    Assert.assertFalse(diff.hasDiff(),"Images are Same");

	}
}
