package stepdefiniations;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;

import javax.imageio.ImageIO;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentTest;
import com.hcl.seleniumfunctions.SeleniumMethods;
import com.qa.util.ScreenshotP;

import AppHooks.ApplicationHooks;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageobjects.AmazonPageObjects;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;

public class amazonpagesteps {

	public WebDriver driver = DriverUtils.DriverFactory.getDriver();
	SeleniumMethods seleniumMethods = new SeleniumMethods();
	AmazonPageObjects amazonPageObjects = new AmazonPageObjects();
	ExtentTest logger=ApplicationHooks.extent.createTest(ApplicationHooks.scenario.getName());
	Scenario scenario=ApplicationHooks.scenario;
	ScreenshotP ss=new ScreenshotP();
	SoftAssert softAssert=new SoftAssert();
	Properties appProp=new Properties();
	Properties orderProp=new Properties();
	String ParentWindow="";
	

	@Given("user is on amazon home page {string}")
	public void user_is_on_amazon_home_page(String url) throws IOException {
		driver.get(url);
		FileInputStream fis=new FileInputStream("./src/test/resources/config/app.properties");
		appProp.load(fis);
		softAssert.assertEquals(driver.getCurrentUrl(), appProp.getProperty("pageurl"));
		softAssert.assertEquals(driver.getTitle(),appProp.getProperty("title") );
		ParentWindow=driver.getWindowHandle();
	}

	@When("Mousehover on Mobiles tab")
	public void mousehover_on_mobiles_tab() throws IOException {
		seleniumMethods.mousehover(driver.findElement(amazonPageObjects.linkMobiles));
		
	}

	@When("Click on Mobiles Tab")
	public void click_on_mobiles_tab() {
		seleniumMethods.click(driver.findElement(amazonPageObjects.linkMobiles));
	}

	@When("read sublinks under mobiles tab and print on console with count")
	public void read_sublinks_under_mobiles_tab_and_print_on_console_with_count() {
		List<String> list = seleniumMethods.getTextOfElements(driver.findElements(amazonPageObjects.sublinks));
		int count = 0;
		System.out.println("------Menus---------");
		for (String str : list) {
			System.out.println(str);
			count++;
		}
		System.out.println("Menus Count:" + count);
	}

	@Then("compare mobiles page screenshot with original screenshot")
	public void compare_mobiles_page_screenshot_with_original_screenshot() throws IOException {
		Screenshot screenshot = new AShot().takeScreenshot(driver);
		ImageIO.write(screenshot.getImage(), "png",
				new File("C:\\Users\\Mahesh\\Automation2023\\auto\\src\\main\\java\\AmazonScreenshots\\Actual.png"));

		ImageDiffer imgDiff = new ImageDiffer();
		ImageDiff diff = imgDiff.makeDiff(
				ImageIO.read(new File(
						"C:\\Users\\Mahesh\\Automation2023\\auto\\src\\main\\java\\AmazonScreenshots\\Actual.png")),
				ImageIO.read(new File(
						"C:\\Users\\Mahesh\\Automation2023\\auto\\src\\main\\java\\AmazonScreenshots\\Expected.png")));
		softAssert.assertFalse(diff.hasDiff(), "Images are Same");
	}

	@When("Mousehover On Latops Accessories and Click On Brand")
	public void mousehover_on_latops_accessories_and_click_on_brand() throws InterruptedException {
		seleniumMethods.mousehover(driver.findElement(amazonPageObjects.linkLaptopsAccessories));
		seleniumMethods.waitForElementLoad(amazonPageObjects.linkBrand, 10);
		seleniumMethods.click(driver.findElement(amazonPageObjects.linkBrand));
	}

	@When("Set Min and Max Price and Go")
	public void set_min_and_max_price_and_go() throws IOException {
		FileInputStream fis=new FileInputStream("./src/test/resources/config/order.properties");
		orderProp.load(fis);
		seleniumMethods.enterText(driver.findElement(amazonPageObjects.tbLowPrice), orderProp.getProperty("minprice"));
		seleniumMethods.enterText(driver.findElement(amazonPageObjects.tbHighPrice), orderProp.getProperty("maxprice"));
		seleniumMethods.click(driver.findElement(amazonPageObjects.btnGo));
	}

	@When("Search Gaming Laptop")
	public void search_gaming_laptop() {
		seleniumMethods.enterText(driver.findElement(amazonPageObjects.tbSearchLaptop), "Gaming Laptop");
		seleniumMethods.click(driver.findElement(amazonPageObjects.btnSearch));
	}

	@When("click On First Gaming Laptop On Screen")
	public void click_on_first_gaming_laptop_on_screen() {
		seleniumMethods.click(driver.findElement(amazonPageObjects.firstLaptop));
	}

	@When("verify Price Should Be Greater Than or Equal to Zero")
	public void verify_price_should_be_greater_than_or_equal_to_zero() {
		Set<String> allWindows = driver.getWindowHandles();
		seleniumMethods.swithToWindow(allWindows);
		int price = Integer.parseInt(
				seleniumMethods.getTextOfElement(driver.findElement(amazonPageObjects.laptopPrice)).replace(",", ""));
		if (price >= 0) {
			softAssert.assertTrue(true);
		} else {
			softAssert.assertTrue(false);
		}
		System.out.println(price);

	}

	@When("select Delivery Location and Enter Pincode")
	public void select_delivery_location_and_enter_pincode() throws InterruptedException {
		seleniumMethods.click(driver.findElement(amazonPageObjects.updatelocation));
		Thread.sleep(3000);
		seleniumMethods.click(driver.findElement(amazonPageObjects.tbPincode));
		Actions actions = new Actions(driver);
		actions.sendKeys(Keys.NUMPAD5).sendKeys(Keys.NUMPAD0).sendKeys(Keys.NUMPAD0).sendKeys(Keys.NUMPAD0)
				.sendKeys(Keys.NUMPAD7).sendKeys(Keys.NUMPAD2).build().perform();
		seleniumMethods.click(driver.findElement(amazonPageObjects.btnApply));
	}

	@When("print Customer Rating On Console")
	public void print_customer_rating_on_console() throws InterruptedException {
		Thread.sleep(3000);
		seleniumMethods.scrollDown(driver.findElement(amazonPageObjects.lblCustomerReviews));
		String rating = seleniumMethods.getTextOfElement(driver.findElement(amazonPageObjects.lblRating));
		System.out.println(rating);

	}

	@When("read Customer Reviews and Write In Excel")
	public void read_customer_reviews_and_write_in_excel() throws IOException {
		seleniumMethods.scrollDown(driver.findElement(amazonPageObjects.lblTopReviewsFromIndia));
		List<String> reviewerNames = seleniumMethods
				.getTextOfElements(driver.findElements(amazonPageObjects.reviewerName));
		List<String> reviews = seleniumMethods.getTextOfElements(driver.findElements(amazonPageObjects.customerReview));
		List<String> names = new ArrayList<String>();

		for (String str : reviewerNames) {
			if (!str.isEmpty()) {
				names.add(str);
			}
		}
//		for (int i = 0; i < names.size(); i++) {
//			System.out.println("--------" + names.get(i) + "------------");
//			System.out.println("*" + reviews.get(i).trim() + "*");
//		}
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet();
		XSSFRow row;
		Map<String, String> reviewsdata = new TreeMap<String, String>();

		for (int i = 0; i < names.size(); i++) {
			reviewsdata.put(names.get(i), reviews.get(i));
		}
		Set<String> keyid = reviewsdata.keySet();
		int rowid = 0;
		String str = "";
//		XSSFCellStyle cs=wb.createCellStyle();
//		cs.setWrapText(true);
		for (String key : keyid) {

			row = sheet.createRow(rowid);
			if (!reviewsdata.get(key).isEmpty()) {
				str = reviewsdata.get(key);
			} else {
				str = "No Review";
			}
			int cellid = 0;
			XSSFCell cell1 = row.createCell(cellid);
			cell1.setCellValue(key);
			// cell1.setCellStyle(cs);
			XSSFCell cell2 = row.createCell(cellid + 1);
			cell2.setCellValue(str);
			// cell2.setCellStyle(cs);
			rowid++;

		}
		FileOutputStream file = new FileOutputStream(
				"D:\\Serenity2023\\cucumber\\AmazonExcelFiles\\amazonreviews.xlsx");

		wb.write(file);
		wb.close();

	}

	@When("scroll Up and Click On Add Cart")
	public void scroll_up_and_click_on_add_cart() {
		seleniumMethods.scrollUp(driver.findElement(amazonPageObjects.btnAddCart));
		seleniumMethods.click(driver.findElement(amazonPageObjects.btnAddCart));

	}

	@Then("Verify laptop is added to cart")
	public void verify_laptop_is_added_to_cart() throws InterruptedException {
		seleniumMethods.waitForElementLoad(amazonPageObjects.btnAddedCart, 10);
		softAssert.assertTrue(seleniumMethods.isElementPresent(driver.findElement(amazonPageObjects.btnAddedCart)));
		driver.close();
		driver.switchTo().window(ParentWindow);
		

	}

}
