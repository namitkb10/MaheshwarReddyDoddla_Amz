package stepdefiniations;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class uberbookingsteps {
	
	@Given("User wants select a car type {string} type from uber app")
	public void user_wants_select_a_car_type_type_from_uber_app(String carType) {
		System.out.println("Step1: "+carType);
	  
	}

	@When("user select card {string} and pick up point {string} and Drop Point {string}")
	public void user_select_card_and_pick_up_point_and_drop_point(String carType, String pickupPoint, String dropPoint) {
		System.out.println("Step2: "+carType+" "+pickupPoint+" "+dropPoint);
	}

	@Then("Driver starts the journey")
	public void driver_starts_the_journey() {
		System.out.println("Step3: ");
	}

	@Then("Driver Ends the journey")
	public void driver_ends_the_journey() {
		System.out.println("Step4: ");
	}

	@Then("User pays {int} USD")
	public void user_pays_usd(Integer price) {
		System.out.println("Step5: "+price);
	}

}
