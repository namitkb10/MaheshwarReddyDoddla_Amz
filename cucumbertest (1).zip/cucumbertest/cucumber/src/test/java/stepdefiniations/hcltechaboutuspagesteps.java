package stepdefiniations;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import AppHooks.ApplicationHooks;
import DriverUtils.DriverFactory;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;

public class hcltechaboutuspagesteps{
	
	public WebDriver driver=DriverUtils.DriverFactory.getDriver();
	
	@When("Navigate to Contact us page")
	public void navigate_to_contact_us_page() throws InterruptedException {
		driver.findElement(By.linkText("Contact Us")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("onetrust-accept-btn-handler")).click();

	}

	@Given("navigate to about us page with this url {string}")
	public void navigate_to_about_us_page_with_this_url(String navigateUrl) {
		driver.navigate().to(navigateUrl);

	}

	@When("Go To About us tab and select Corporate Social Responsibility")
	public void go_to_about_us_tab_and_select_corporate_social_responsibility() throws InterruptedException {
		Actions actions = new Actions(driver);
		actions.moveToElement(driver.findElement(By.xpath("//a[@title='About Us']"))).build().perform();
		driver.findElement(By.xpath("//a[@title='Corporate Social Responsibility']")).click();

	}

	@When("get the text of super charging progress and write in text document")
	public void get_the_text_of_super_charging_progress_and_write_in_text_document() throws IOException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);",
				driver.findElement(By.xpath("//h2[text()='Supercharging Progress, Responsibly']")));

		File file = new File("D:\\Serenity2023\\cucumber\\src\\test\\resources\\TextFiles\\ActualContent.txt");
		if (file.exists()) {
			file.delete();
			FileWriter fw = new FileWriter(file);
			fw.write(driver.findElement(By.xpath("//div[@class='additional-information-info']")).getText());
			fw.close();
		}

	}

	@Then("verify text docuement with original document")
	public void verify_text_docuement_with_original_document() throws IOException {
		
		File actualFile=new File("D:\\Serenity2023\\cucumber\\src\\test\\resources\\TextFiles\\ActualContent.txt");
		File expectedFile=new File("D:\\Serenity2023\\cucumber\\src\\test\\resources\\TextFiles\\ExpectedContent.txt");
		if(Arrays.equals(Files.readAllBytes(actualFile.toPath()), Files.readAllBytes(expectedFile.toPath())))
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
	    
	}
	
	

}
