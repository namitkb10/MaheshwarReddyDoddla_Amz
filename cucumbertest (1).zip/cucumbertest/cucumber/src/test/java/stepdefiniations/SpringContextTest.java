package stepdefiniations;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

import springapp.SpringDemoApplication;

@SpringBootTest(classes = SpringDemoApplication.class)
public class SpringContextTest {
	    @Test
	    public void whenSpringContextIsBootstrapped_thenNoExceptions() {
	    }
}
