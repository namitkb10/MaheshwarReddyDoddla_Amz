package stepdefiniations;

import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class registrationsteps {
	
	
	
@Given("user is on registartion on page")
public void user_is_on_registartion_on_page() {

	System.out.println("Registartion page");
}
    

@When("user enters following user details")
public void user_enters_following_user_details(DataTable dataTable) {
	
	List<List<String>> list=dataTable.asLists(String.class);
	for(List<String> li:list)
	{
		System.out.println(li);
	}
   
}

@Then("user registartion should be successful")
public void user_registartion_should_be_successful() {
	System.out.println("Successful");
  
}

@When("user enters following user details with columns")
public void user_enters_following_user_details_with_columns(DataTable dataTable) {
	
	List<Map<String,String>> li=dataTable.asMaps(String.class,String.class);
	System.out.println(li);
	for(Map<String,String> map:li)
	{
		System.out.println(map.get("name"));
		System.out.println(map.get("skill"));
		System.out.println(map.get("mail"));
		System.out.println(map.get("phone"));
	}
    
}


}
