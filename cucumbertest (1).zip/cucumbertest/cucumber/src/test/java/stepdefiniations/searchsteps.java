package stepdefiniations;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class searchsteps {

	@Given("Launch Browser")
	public void launch_browser() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Test");	    
	}

	@When("Enter <URL>")
	public void enter_url() {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("Verify Google page <title>")
	public void verify_google_page_title() {
	    // Write code here that turns the phrase above into concrete actions
	   
	}
}
