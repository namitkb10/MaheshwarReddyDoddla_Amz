package testrunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import stepdefiniations.SpringIntegrationTest;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"src/test/resources/AppFeatures/version.feature"},
		glue= {"stepdefiniations"})

public class CucumberIntegrationTest extends SpringIntegrationTest {

}
