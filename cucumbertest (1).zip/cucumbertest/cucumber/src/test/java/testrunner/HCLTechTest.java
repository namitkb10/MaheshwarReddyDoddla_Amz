package testrunner;


import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.CucumberOptions.SnippetType;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"src/test/resources/AppFeatures/hcltech.feature"},
		glue= {"stepdefiniations","AppHooks"},
		plugin= {"pretty","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"}
		)
//@RunWith(Cucumber.class)
//@CucumberOptions(
//		features= {"src/test/resources/AppFeatures/hcltech.feature"},
//		glue= {"stepdefiniations","AppHooks"},
//		plugin= {"pretty"}
//		)
public class HCLTechTest {
	
}



