package com.hcl.seleniumfunctions;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class SeleniumMethods{
	
	public WebDriver driver=DriverUtils.DriverFactory.getDriver();
	
	public  void mousehover(WebElement element)
	{
		if(element.isDisplayed())
		{
			Actions actions=new Actions(driver);
			actions.moveToElement(element).build().perform();
		}
		else
		{
			System.out.println("Element Not Found");
		}
	}
	public  void click(WebElement element)
	{
		element.click();
	}
	
	public  String getAttributeOfElement(WebElement element,String attribute)
	{
		String text=element.getAttribute(attribute);
		return text;
		
	}
	public  List<String> getAttributeOfElements(List<WebElement> elements,String attribute)
	{
		List<String> li=new ArrayList<String>();
		for(WebElement ele:elements)
		{
		li.add(ele.getAttribute(attribute));
		}
		return li;
		
	}
	public  List<String> getTextOfElements(List<WebElement> elements)
	{
		List<String> li=new ArrayList<String>();
		for(WebElement ele:elements)
		{
		li.add(ele.getText());
		}
		return li;
		
	}
	public String getTextOfElement(WebElement element)
	{
		String str=element.getText();
		return str;
		
	}
	
	public void enterText(WebElement element,String text)
	{
		element.sendKeys(text);
	}
	
	public void swithToWindow(Set<String> allWindows)
	{
		Iterator<String> iterator=allWindows.iterator();
		while(iterator.hasNext())
		{	
		driver.switchTo().window(iterator.next());
		}
	}
	
	public void scrollDown(WebElement element)
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView({block:'center'});", element);
	
	
	}
	public void scrollUp(WebElement element)
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element);

	}
	
	public boolean isElementPresent(WebElement element)
	{
		if(element.isDisplayed())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void waitForElementLoad(By by,int seconds)
	{
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(seconds));
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
				
	}

}
